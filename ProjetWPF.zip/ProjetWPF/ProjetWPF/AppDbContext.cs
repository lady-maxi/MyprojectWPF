﻿using Microsoft.EntityFrameworkCore;

namespace ProjetWPF
{
    public class AppDbContext : DbContext
    {
        public DbSet<Order> Orders { get; set; } // La table correspond à la classe Order

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
    }
}
