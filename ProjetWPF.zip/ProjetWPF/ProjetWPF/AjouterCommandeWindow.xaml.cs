﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;
using System.Windows;

namespace ProjetWPF
{
    public partial class AjouterCommandeWindow : Window
    {
        public DataTable ListeProduits { get; set; } = new DataTable();
        public ObservableCollection<ProduitCommande> ProduitsCommandes { get; set; } = new();

        public AjouterCommandeWindow()
        {
            InitializeComponent();
            DataContext = this;

            ChargerProduits();

            dgProduits.ItemsSource = ProduitsCommandes;
            ProduitsCommandes.Add(new ProduitCommande());
            ProduitsCommandes[0].PropertyChanged += Produit_PropertyChanged;


            // Surveille les changements pour chaque ligne
            ProduitsCommandes.CollectionChanged += (s, e) =>
            {
                if (e.NewItems != null)
                {
                    foreach (var item in e.NewItems)
                    {
                        if (item is ProduitCommande pc)
                            pc.PropertyChanged += Produit_PropertyChanged;
                    }
                }
            };
        }

        private void ChargerProduits()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Server=LADY\SQLEXPRESS;Database=Northwind;Trusted_Connection=True;TrustServerCertificate=True;"))
                {
                    conn.Open();
                    string query = "SELECT ProductID, ProductName, UnitPrice FROM Products";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    adapter.Fill(ListeProduits);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur chargement produits : " + ex.Message);
            }
        }

        private void Produit_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "ProduitId" && sender is ProduitCommande produit)
            {
                var row = ListeProduits.AsEnumerable()
                    .FirstOrDefault(r => Convert.ToInt32(r["ProductID"]) == produit.ProduitId);
                if (row != null)
                {
                    produit.PrixUnitaire = Convert.ToDecimal(row["UnitPrice"]);
                }
            }
            RecalculerTotal();

        }
        private void RecalculerTotal()
        {
            decimal total = ProduitsCommandes.Sum(p => p.PrixUnitaire * p.Quantite);
            txtTotalCommande.Text = total.ToString("C2"); // Format monétaire (ex: 125,00 €)
        }

        private void AjouterCommande_Click(object sender, RoutedEventArgs e)
        {
            string clientId = txtClientID.Text;
            DateTime? dateCommande = dpOrderDate.SelectedDate;

            if (string.IsNullOrWhiteSpace(clientId) || dateCommande == null)
            {
                MessageBox.Show("Veuillez remplir tous les champs.");
                return;
            }

            if (ProduitsCommandes.Count == 0 || ProduitsCommandes.All(p => p.ProduitId == 0))
            {
                MessageBox.Show("Veuillez ajouter au moins un produit.");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(@"Server=LADY\SQLEXPRESS;Database=Northwind;Trusted_Connection=True;TrustServerCertificate=True"))
                {
                    conn.Open();
                    SqlTransaction transaction = conn.BeginTransaction();

                    try
                    {
                        // Insérer dans Orders
                        string insertOrderQuery = "INSERT INTO Orders (CustomerID, OrderDate) OUTPUT INSERTED.OrderID VALUES (@ClientID, @OrderDate)";
                        SqlCommand cmdOrder = new SqlCommand(insertOrderQuery, conn, transaction);
                        cmdOrder.Parameters.AddWithValue("@ClientID", clientId);
                        cmdOrder.Parameters.AddWithValue("@OrderDate", dateCommande);
                        int orderId = (int)cmdOrder.ExecuteScalar();

                        // Insérer les lignes dans Order Details
                        foreach (var ligne in ProduitsCommandes)
                        {
                            if (ligne.ProduitId == 0 || ligne.Quantite <= 0) continue;

                            string insertDetailQuery = "INSERT INTO [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount) VALUES (@OrderID, @ProductID, @UnitPrice, @Quantity, 0)";
                            SqlCommand cmdDetail = new SqlCommand(insertDetailQuery, conn, transaction);
                            cmdDetail.Parameters.AddWithValue("@OrderID", orderId);
                            cmdDetail.Parameters.AddWithValue("@ProductID", ligne.ProduitId);
                            cmdDetail.Parameters.AddWithValue("@UnitPrice", ligne.PrixUnitaire);
                            cmdDetail.Parameters.AddWithValue("@Quantity", ligne.Quantite);
                            cmdDetail.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        MessageBox.Show("Commande enregistrée avec succès !");
                        this.Close(); 
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Erreur lors de l’enregistrement : " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur de connexion : " + ex.Message);
            }
        }

    }
}
