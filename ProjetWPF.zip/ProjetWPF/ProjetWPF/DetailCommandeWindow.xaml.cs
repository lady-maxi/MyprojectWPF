﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Windows;

namespace ProjetWPF
{
    public partial class DetailCommandeWindow : Window
    {
        private int orderId;

        public DetailCommandeWindow(int orderId)
        {
            InitializeComponent();
            this.orderId = orderId;
            ChargerProduitsCommande();
        }

        private void ChargerProduitsCommande()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Server=LADY\SQLEXPRESS;Database=Northwind;Trusted_Connection=True;TrustServerCertificate=True"))
                {
                    conn.Open();
                    string query = @"SELECT od.ProductID, p.ProductName, od.Quantity, od.UnitPrice
                                     FROM [Order Details] od
                                     INNER JOIN Products p ON od.ProductID = p.ProductID
                                     WHERE od.OrderID = @OrderID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@OrderID", orderId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgProduitsCommande.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des produits : " + ex.Message);
            }
        }
    }
}
