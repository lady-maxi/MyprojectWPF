﻿using System.ComponentModel;

public class ProduitCommande : INotifyPropertyChanged
{
    private int _produitId;
    private int _quantite;
    private decimal _prixUnitaire;

    public int ProduitId
    {
        get => _produitId;
        set
        {
            if (_produitId != value)
            {
                _produitId = value;
                OnPropertyChanged(nameof(ProduitId));
            }
        }
    }

    public int Quantite
    {
        get => _quantite;
        set
        {
            if (_quantite != value)
            {
                _quantite = value;
                OnPropertyChanged(nameof(Quantite));
            }
        }
    }

    public decimal PrixUnitaire
    {
        get => _prixUnitaire;
        set
        {
            if (_prixUnitaire != value)
            {
                _prixUnitaire = value;
                OnPropertyChanged(nameof(PrixUnitaire));
            }
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged(string propertyName)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
