﻿using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace ProjetWPF
{
    public partial class MainWindow : Window
    {
        private readonly OrderService _orderService;
        public ObservableCollection<Order> Orders { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            _orderService = new OrderService();
            LoadOrders();
        }

        private void LoadOrders()
        {
            try
            {
                Orders = new ObservableCollection<Order>(_orderService.GetAllCommandes());
                dgOrders.ItemsSource = Orders;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des commandes: {ex.Message}");
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string clientId = txtSearchClientId.Text.Trim();
            if (!string.IsNullOrEmpty(clientId))
            {
                try
                {
                    var commandesFiltrees = _orderService.GetCommandesByClientId(clientId);
                    dgOrders.ItemsSource = commandesFiltrees;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur lors de la recherche: {ex.Message}");
                }
            }
        }

        private void SearchOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtSearchOrderId.Text, out int orderId))
            {
                try
                {
                    var commande = _orderService.GetCommandeById(orderId);
                    if (commande != null)
                    {
                        dgOrders.ItemsSource = new ObservableCollection<Order> { commande };
                    }
                    else
                    {
                        MessageBox.Show("Aucune commande trouvée avec cet ID");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur lors de la recherche: {ex.Message}");
                }
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtClientId.Text))
            {
                MessageBox.Show("Le numéro client est requis");
                return;
            }

            var nouvelleCommande = new Order
            {
                CustomerID = txtClientId.Text.Trim(),
                OrderDate = dpOrderDate.SelectedDate ?? DateTime.Now
            };

            try
            {
                _orderService.AjouterCommande(nouvelleCommande);
                LoadOrders();
                MessageBox.Show("Commande ajoutée avec succès");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur: {ex.Message}");
            }
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrders.SelectedItem is Order commandeSelectionnee)
            {
                commandeSelectionnee.CustomerID = txtClientId.Text.Trim();
                commandeSelectionnee.OrderDate = dpOrderDate.SelectedDate ?? commandeSelectionnee.OrderDate;

                try
                {
                    _orderService.ModifierCommande(commandeSelectionnee);
                    LoadOrders();
                    MessageBox.Show("Commande modifiée avec succès");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une commande");
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (dgOrders.SelectedItem is Order commandeSelectionnee)
            {
                if (MessageBox.Show("Confirmez-vous la suppression de cette commande?",
                    "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        _orderService.SupprimerCommande(commandeSelectionnee.OrderID);
                        LoadOrders();
                        MessageBox.Show("Commande supprimée avec succès");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erreur: {ex.Message}");
                    }
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner une commande");
            }
        }

        private void dgOrders_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dgOrders.SelectedItem is Order selectedOrder)
            {
                txtClientId.Text = selectedOrder.CustomerID;
                dpOrderDate.SelectedDate = selectedOrder.OrderDate;
            }
        }
    }
}