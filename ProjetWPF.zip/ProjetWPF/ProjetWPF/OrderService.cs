﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace ProjetWPF
{
    public class OrderService
    {
        private string connectionString = @"Server=LADY\SQLEXPRESS;Database=Northwind;Trusted_Connection=True;TrustServerCertificate=true;";

        public List<Order> GetAllCommandes()
        {
            List<Order> commandes = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OrderID, CustomerID, OrderDate FROM Orders";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        commandes.Add(new Order
                        {
                            OrderID = reader.GetInt32(0),
                            CustomerID = reader.GetString(1),
                            OrderDate = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                        });
                    }
                }
            }

            return commandes;
        }

        public List<Order> GetCommandesByClientId(string clientId)
        {
            List<Order> commandes = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OrderID, CustomerID, OrderDate FROM Orders WHERE CustomerID = @CustomerID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerID", clientId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            commandes.Add(new Order
                            {
                                OrderID = reader.GetInt32(0),
                                CustomerID = reader.GetString(1),
                                OrderDate = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                            });
                        }
                    }
                }
            }

            return commandes;
        }

        public Order GetCommandeById(int orderId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OrderID, CustomerID, OrderDate FROM Orders WHERE OrderID = @OrderID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderID", orderId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Order
                            {
                                OrderID = reader.GetInt32(0),
                                CustomerID = reader.GetString(1),
                                OrderDate = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                            };
                        }
                    }
                }
            }

            return null;
        }

        public int AjouterCommande(Order order)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Orders (CustomerID, OrderDate)  VALUES (@CustomerID, @OrderDate)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerID", order.CustomerID);
                    command.Parameters.AddWithValue("@OrderDate", (object?)order.OrderDate ?? DBNull.Value);

                    return (int)command.ExecuteScalar();
                }
            }
        }

        public void ModifierCommande(Order order)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Orders SET CustomerID = @CustomerID, OrderDate = @OrderDate WHERE OrderID = @OrderID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerID", order.CustomerID);
                    command.Parameters.AddWithValue("@OrderDate", (object?)order.OrderDate ?? DBNull.Value);
                    command.Parameters.AddWithValue("@OrderID", order.OrderID);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void SupprimerCommande(int orderId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // Supprimer d'abord dans Order Details
                    string deleteDetailsQuery = "DELETE FROM [Order Details] WHERE OrderID = @OrderID";
                    using (SqlCommand commandDetails = new SqlCommand(deleteDetailsQuery, connection, transaction))
                    {
                        commandDetails.Parameters.AddWithValue("@OrderID", orderId);
                        commandDetails.ExecuteNonQuery();
                    }

                    // Ensuite supprimer dans Orders
                    string deleteOrderQuery = "DELETE FROM Orders WHERE OrderID = @OrderID";
                    using (SqlCommand commandOrder = new SqlCommand(deleteOrderQuery, connection, transaction))
                    {
                        commandOrder.Parameters.AddWithValue("@OrderID", orderId);
                        commandOrder.ExecuteNonQuery();
                    }

                    transaction.Commit(); //  Confirmer la suppression
                }
                catch (Exception ex)
                {
                    transaction.Rollback(); //  Annuler si erreur
                    MessageBox.Show("Erreur lors de la suppression : " + ex.Message);
                }
            }
        }

    }
}
