﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;

namespace ProjetWPF
{
    public class OrderService
    {
        private string connectionString = "Server=localhost;Database=Northwind;Trusted_Connection=True;TrustServerCertificate=true;";

        public List<Order> GetAllCommandes()
        {
            List<Order> commandes = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OrderID, CustomerID, OrderDate FROM Orders";

                using (SqlCommand command = new SqlCommand(query, connection))
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        commandes.Add(new Order
                        {
                            OrderID = reader.GetInt32(0),
                            CustomerID = reader.IsDBNull(1) ? null : reader.GetString(1),
                            OrderDate = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                        });
                    }
                }
            }
            return commandes;
        }
        public Order GetCommandeById(int orderId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OrderID, CustomerID, OrderDate FROM Orders WHERE OrderID = @OrderID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderID", orderId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Order
                            {
                                OrderID = reader.GetInt32(0),
                                CustomerID = reader.IsDBNull(1) ? null : reader.GetString(1),
                                OrderDate = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                            };
                        }
                    }
                }
            }
            return null;
        }

        public List<ProduitCommande> GetOrderDetails(int orderId)
        {
            var details = new List<ProduitCommande>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = @"SELECT od.OrderID, od.ProductID, od.Quantity, od.UnitPrice 
                        FROM [Order Details] od 
                        WHERE od.OrderID = @OrderID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderID", orderId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            details.Add(new ProduitCommande
                            {
                                CommandeId = reader.GetInt32(0),
                                ProduitId = reader.GetInt32(1),
                                Quantite = reader.GetInt16(2),
                                PrixUnitaire = reader.GetDecimal(3)
                            });
                        }
                    }
                }
            }
            return details;
        }
        public List<Order> GetCommandesByClientId(string clientId)
        {
            List<Order> commandes = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OrderID, CustomerID, OrderDate FROM Orders WHERE CustomerID = @ClientId";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ClientId", clientId);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            commandes.Add(new Order
                            {
                                OrderID = reader.GetInt32(0),
                                CustomerID = reader.IsDBNull(1) ? null : reader.GetString(1),
                                OrderDate = reader.IsDBNull(2) ? (DateTime?)null : reader.GetDateTime(2)
                            });
                        }
                    }
                }
            }
            return commandes;
        }

        public void AjouterCommande(Order commande)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO Orders (CustomerID, OrderDate) VALUES (@CustomerID, @OrderDate)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerID", commande.CustomerID ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@OrderDate", commande.OrderDate ?? (object)DBNull.Value);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void ModifierCommande(Order commande)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "UPDATE Orders SET CustomerID = @CustomerID, OrderDate = @OrderDate WHERE OrderID = @OrderID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderID", commande.OrderID);
                    command.Parameters.AddWithValue("@CustomerID", commande.CustomerID ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@OrderDate", commande.OrderDate ?? (object)DBNull.Value);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void SupprimerCommande(int id)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "DELETE FROM Orders WHERE OrderID = @OrderID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OrderID", id);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
