﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace ProjetWPF
{
    public class CommandeRepository
    {
        public static int AjouterCommande(Order commande, List<ProduitCommande> details)
        {
            using (SqlConnection conn = new SqlConnection(@"Server=LADY\SQLEXPRESS;Database=Northwind;Trusted_Connection=True;TrustServerCertificate=true;"))
            {
                conn.Open();

                string insertCommande = "INSERT INTO Orders (CustomerID, OrderDate) VALUES (@CustomerID, @OrderDate); SELECT SCOPE_IDENTITY();";
                SqlCommand cmdCommande = new SqlCommand(insertCommande, conn);
                cmdCommande.Parameters.AddWithValue("@CustomerID", commande.CustomerID);
                cmdCommande.Parameters.AddWithValue("@OrderDate", commande.OrderDate ?? (object)DBNull.Value);

                int commandeId = Convert.ToInt32(cmdCommande.ExecuteScalar());

                foreach (var detail in details)
                {
                    string insertDetail = "INSERT INTO [Order Details] (OrderID, ProductID, Quantity, UnitPrice) VALUES (@OrderID, @ProductID, @Quantity, @UnitPrice)";
                    SqlCommand cmdDetail = new SqlCommand(insertDetail, conn);
                    cmdDetail.Parameters.AddWithValue("@OrderID", commandeId);
                    cmdDetail.Parameters.AddWithValue("@ProductID", detail.ProduitId);
                    cmdDetail.Parameters.AddWithValue("@Quantity", detail.Quantite);
                    cmdDetail.Parameters.AddWithValue("@UnitPrice", detail.PrixUnitaire);

                    cmdDetail.ExecuteNonQuery();
                }

                return commandeId;
            }
        }
    }
}
