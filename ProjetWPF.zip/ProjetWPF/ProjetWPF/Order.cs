﻿using System;

namespace ProjetWPF
{
    public class Order
    {
        public int OrderID { get; set; } // Vérifie que tu assignes bien un int ici

        public string? CustomerID { get; set; } // Doit rester une string

        public DateTime? OrderDate { get; set; } // Nullable pour éviter d'autres erreurs
    }
}
