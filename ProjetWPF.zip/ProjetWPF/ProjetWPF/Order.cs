﻿using System;

namespace ProjetWPF
{
    public class Order
    {


       
        public int OrderID { get; set; } 

        public string? CustomerID { get; set; } 

        public DateTime? OrderDate { get; set; }

        public List<Order>? Orders { get; set; } = new List<Order>();

        public List<ProduitCommande> Produits { get; set; } = new List<ProduitCommande>();
    }
}
